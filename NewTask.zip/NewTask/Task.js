var users = [];
function entrance() {
    var name = document.getElementById('Name').value;
    var password = document.getElementById('Password').value;
    for(var i = 0; i < users.length; i++);
    if(name.length == 0 || password.length == 0){
        // alert("Enter Name and password");
        return 0;
    }
    users.push({
        name: name,
        password: password,
        id: i,
    });

    addLocal();
    console.log(users);
}
function addLocal() {               // ID == Name // ID  == key 
    var List = document.getElementsByClassName('list')[0];
    List.innerHTML = '';
    users.forEach((item, index) => {
        localStorage.setItem(item.id, "Name - " + item.name + "   " + "Password - " + item.password);
        
        // var LogIn = document.getElementById('login');
        // LogIn.onclick = function () {YourPage()};

        var listItems = document.createElement('li');
        listItems.innerHTML = localStorage.getItem(item.id,  item.name + item.password);
        List.appendChild(listItems);

        // listItems.onclick = ThisUser();
    });

}
// function ThisUser() {

// }