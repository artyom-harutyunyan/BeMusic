function showContainer() {
    document.getElementById('block').style.display = "none";
    document.getElementsByClassName('AddContainer')[0].style.display = "block";
}