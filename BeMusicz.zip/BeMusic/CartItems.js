// var ArrCart = [];
// function GoToCart() {
//     var name = document.getElementById('name').value;
//     var description = document.getElementById('description').value;
//     var Image = document.getElementById('file').files[0];
//     var ProductImage = URL.createObjectURL(Image);
//     var Cost = document.getElementById('cost').value;
//     var quantity = 1;
//     ArrCart.push({
//         Image: ProductImage,
//         name: name,
//         description: description,
//         quantity: quantity,
//         Cost: Cost,
//     });
//     AddCartProduct();
// }
// function AddCartProduct() {
//     var cart = document.getElementsByClassName('element')[0];
//     ArrCart.forEach((item, index) => {
//     var CartItemElement = document.createElement('div');
//     CartItemElement.className = 'TestOnCart';
//     cart.appendChild(CartItemElement);

//     var CartProductImage = document.createElement('div');
//     CartProductImage.className = 'Productimage';
//     CartProductImage.style.background = `url(${item.Image}) center/cover`;
//     CartItemElement.appendChild(CartProductImage);

//     var CartProductName = document.createElement('div');
//     CartProductName.className = 'ProductName';
//     CartItemElement.appendChild(CartProductName);
//     CartProductName.innerHTML = index.name;

//     var CartProductDescription = document.createElement('div');
//     CartProductDescription.className = 'ProductDescription';
//     CartItemElement.appendChild(CartProductDescription);
//     CartProductDescription.innerHTML = index.description;

//     var CartProductQuantity = document.createElement('div');
//     CartProductQuantity.className = 'Quantity';
//     CartItemElement.appendChild(CartProductQuantity);
//     CartProductQuantity.innerHTML = index.Quantity;

//     var CartProductCost = document.createElement('div');
//     CartProductCost.className = 'ProductCost';
//     CartProductCost.appendChild(CartProductQuantity);
//     CartProductCost.innerHTML = index.Cost;
//     });
// }
