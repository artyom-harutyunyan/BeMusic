var ProductMarket = [];
function AddProduct() {
    var name = document.getElementById('name').value;
    var description = document.getElementById('description').value;
    var Image = document.getElementById('file').files[0];
    var ProductImage = URL.createObjectURL(Image);
    var Cost = document.getElementById('cost').value;
    var Buy = document.getElementsByClassName('buyThis');
    var Quantity = document.getElementsByClassName('Quantity');
    for(var i = 0; i < ProductMarket.length; i++);
    ProductMarket.push({
        name: name,
        description: description,
        photo: ProductImage,
        Cost: Cost,
        buy: Buy,
        id: i,
    });

    console.log(ProductMarket);
    // console.log(AddProduct);
    // console.log(name, description, ProductImage, Cost);
    toCreate();
    // Buy.onclick = CartNewItem();
    // document.getElementsByClassName('buyThis').onclick = CartNewItem();


function toCreate() {
    var section = document.getElementsByClassName('PriceListContainer')[0];
    section.innerHTML = '';
    ProductMarket.forEach((item, index) => {
        var ProductElement = document.createElement('div');
        ProductElement.className = 'PriceElement';

        var ProductName = document.createElement('span');
        ProductName.className = 'name';
        ProductElement.appendChild(ProductName);
        ProductName.innerHTML = item.name;

        var ProductDescription = document.createElement('span');
        ProductDescription.className = 'description';
        ProductElement.appendChild(ProductDescription);
        ProductDescription.innerHTML = item.description;
        
        var Image = document.createElement('div');
        Image.className = 'image';
        Image.style.background = `url(${item.photo}) center/cover`;
        ProductElement.appendChild(Image);

        var Price = document.createElement('span');
        Price.className = 'price';
        ProductElement.appendChild(Price);
        Price.innerHTML = "$" + item.Cost;

        var buyButton = document.createElement('button');
        buyButton.className = "buyThis";
        buyButton.innerHTML = "Buy This";
        // buyButton.setAttribute('onclick',GoToCart());
        Price.appendChild(buyButton);

        section.appendChild(ProductElement);


        buyButton.onclick = function() {GoToCart()};
       

        function GoToCart() {
            var ArrCart = [];
            Quantity = document.getElementsByClassName('Quantity')[0];
            for(var q = 1; q < ArrCart.length; q++);
            ArrCart.push({
                CartName: name,
                CartDescription: description,
                CartPhoto: ProductImage,
                CartCost: Cost,
                Quantity: Quantity,
                CartId: q,
            });
    
            console.log(ArrCart);
            if(item.CartId == item.id) {
                item.Quantity += 1;
            }else {
            var CartSection = document.getElementsByClassName('element')[0];
            ProductMarket.forEach((item, index) => {
                var CartElement = document.createElement('div');
                CartElement.className = 'TestOnCart';
                CartSection.appendChild(CartElement);
    
                var CartImage = document.createElement('div');
                CartImage.className = 'Productimage';
                CartImage.style.background = `url(${item.photo}) center/cover`;
                CartElement.appendChild(CartImage);

                var CartName = document.createElement('div');
                CartName.className = 'ProductName';
                CartName.innerHTML = item.name;
                CartElement.appendChild(CartName);

                var CartDescription = document.createElement('div');
                CartDescription.className = 'ProductDescription';
                CartDescription.innerHTML = item.description;
                CartElement.appendChild(CartDescription);

                var CartQuantity = document.createElement('div');
                CartQuantity.className = 'Quantity';
                CartQuantity.innerHTML = 1;
                CartElement.appendChild(CartQuantity);

                var CartCost = document.createElement('div');
                CartCost.className = 'ProductCost';
                CartCost.innerHTML = "$" + item.Cost;
                CartElement.appendChild(CartCost);

            

            });
        }
        }
        
        });
    }
}
