function ShowMyCart() {
    document.getElementsByClassName('containerCart')[0].style.display = "block";
}
function CloseMyCart() {
    document.getElementsByClassName('containerCart')[0].style.display = "none";
}